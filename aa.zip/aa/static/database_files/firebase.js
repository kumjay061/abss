// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBOfdfLw7sWPjsXx2PlO8ZbHsxZyyCmaVo",
  authDomain: "zero-a4c52.firebaseapp.com",
  databaseURL: "https://zero-a4c52-default-rtdb.firebaseio.com",
  projectId: "zero-a4c52",
  storageBucket: "zero-a4c52.appspot.com",
  messagingSenderId: "180316382699",
  appId: "1:180316382699:web:25dea0194c2961de9025ae"
};



// initialize firebase
firebase.initializeApp(firebaseConfig);